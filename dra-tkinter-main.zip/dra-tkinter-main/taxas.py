TAXAS_CONVERSAO = {
    "USD para BRL": 5.93,
    "BRL para USD": 1 / 5.93,
    "Rupia para BRL": 0.063,
    "EUR para BRL": 6.17,
    "BRL para EUR": 1 / 6.17,
    "GBP para BRL": 7.56,
    "BRL para GBP": 1 / 7.56,
    # Insira a nova taxa de conversão aqui: BRL para XXX e XXX para BRL
    
}
