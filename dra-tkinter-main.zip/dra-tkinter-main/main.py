from interface import home

if __name__ == "__main__":
    home()