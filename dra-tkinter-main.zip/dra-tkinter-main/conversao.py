from tqdm import tk

from taxas import TAXAS_CONVERSAO

# Insira a variável para armazenar a lista de conversões realizadas
listbox_historico = []

def converter(valor, opcao):
    try:
        if opcao in TAXAS_CONVERSAO:
            resultado = valor * TAXAS_CONVERSAO[opcao]
            unidade = opcao.split()[-1]
            # Insira o código para adicionar a conversão realizada ao histórico
            listbox_historico.append(resultado)
            
            return f"{resultado:.2f} {unidade}"
        else:
            return "Selecione uma opção válida."
    except ValueError:
        return "Por favor, insira um número válido."

# Insira a função get_historico
def get_historico():
    return listbox_historico